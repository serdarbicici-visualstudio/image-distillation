# image-distillation
Python package for image-datasets distillations
